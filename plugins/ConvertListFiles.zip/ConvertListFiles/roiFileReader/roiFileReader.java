/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ConvertListFiles.roiFileReader;
import java.io.*;

/**
 *
 * @author deves
 */
public class roiFileReader {

}
