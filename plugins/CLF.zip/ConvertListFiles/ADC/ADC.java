package ConvertListFiles.ADC;
import java.util.ArrayList;
import ij.*;
import java.io.*;

/**
 *
 * @author Dev�s Guillaume, CENBG
 */

public class ADC{

//declaration
private  ArrayList<int[]> eventList = new ArrayList<int[]>();
private ArrayList<ArrayList<Integer>> map = new ArrayList<ArrayList<Integer>>();
private	ArrayList<Integer> median = new ArrayList<Integer>();
//constructor
public ADC(){
	eventList.add(new int[3]);
	
	median.add(0);
	
}
//destructor
public void finalize(){
}
private void initializeMedianMap(){
for (int i=0;i<65537;i++){
		map.add(new ArrayList<Integer>());
		map.get(i).add(0);
	}
}
//getter
public int[] getEvent(int position){
	return eventList.get(position);
}
private int[] getlastEvent(){
	return eventList.get(getNEvents()-1);
}
public int getNEvents(){
	return eventList.size();
}
public double [] getSpectra(){
	int size=4096;
	double[] spectra=new double[size];
	try{
	
	for (int i=0;i<getNEvents();i++){
			int [] evt=new int[3];
			evt=getEvent(i);
			if (evt[2]<size) spectra[evt[2]]+=1;
			}
	
	}
	catch (Exception e){
	IJ.log(e.toString());
	}
	return spectra;
}
public double [] getSpectra(int size){
	double[] spectra=new double[size];
	try{
		for (int i=0;i<getNEvents();i++){
			int [] evt=new int[3];
			evt=getEvent(i);
			if (evt[2]<size) spectra[evt[2]]+=1;
		}
	}
	catch (Exception e){
		IJ.log(e.toString());
	}
	return spectra;
}
public int getX(int event){
	int [] XYE=getEvent(event);
	return XYE[0];
}
public int getY(int event){
	int [] XYE=getEvent(event);
	return XYE[1];
}
public int getE(int event){
	int [] XYE=getEvent(event);
	return XYE[2];
}
public int getMedianValue(int index){
    return median.get(index);
}

public int getMedianValue(int x, int y){
    return median.get(x+256*y);
}

public int getMedianValue(int x, int y, int sizeY){
    return median.get(x+sizeY*y);
}

//setter
public void addEvent(int[] event){
	eventList.add(event);
}
//functions
public void saveCountsSpectra(String path){
	try{
		PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(path)));
		double [] tab = getSpectra();
		for (int i=0;i<4096;i++) {
			out.println(String.valueOf((int)tab[i]));
		}
		out.close();
	}
	catch (Exception e){
	}
}
public void saveGupixSpectra(String path){
	try{
		PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(path)));
		double [] tab = getSpectra();
		out.println("4096 0");
		for (int i=0;i<4096;i++) {
			out.println(String.valueOf((int)tab[i]));
		}
		out.close();
	}
	catch (Exception e){
	}
}

public void saveChannelCountsSpectra(String path){
	try{
		PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(path)));
		double [] tab = getSpectra();
		for (int i=0;i<4096;i++) {
			out.println(String.valueOf(i)+"\t"+String.valueOf((int)tab[i]));
		}
		out.close();
	}
	catch (Exception e){
	}
}
public void saveXYEListFile(String path){
	try{
		DataOutputStream ops=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(path)));
		
		for (int i=0;i<getNEvents();i++){
			ops.writeShort(getX(i));
			ops.writeShort(getY(i));
			ops.writeInt(getE(i));
		}
		ops.close();
	}
	catch (Exception e){
	}
}
public void saveXYEListFile(String path, Short type){
	//supavisio is little endian type
	//(short)0:pixe;1(rbs);2:Stim;5:erda
	//(short)X size of map
	//(short)Y size of map
	//events: (short)X,(short)Y, (short)E
	try{
		DataOutputStream ops=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(path)));
		ops.writeShort(LittleEndian(type));
		ops.writeShort(LittleEndian((short)255));
		ops.writeShort(LittleEndian((short)255));
		for (int i=1;i<getNEvents();i++){
			if ( ((getX(i)-1) >=0)&((getY(i)-1)>=0)&(getE(i)>0) & getE(i)<4095){
                            ops.writeShort(LittleEndian((short)(getX(i)-1)));
                            ops.writeShort(LittleEndian((short)(getY(i)-1)));
                            ops.writeShort(LittleEndian((short)getE(i)));
                        }
		}
		ops.close();
	}
	catch (Exception e){
	}
}

private int LittleEndian (short v){
    return ((v>>8)|(v<<8));
}

public ArrayList<Integer> medianSort(){
	//sort event according to X,Y
	try{
            initializeMedianMap();
            for (int i=1;i<getNEvents();i++){
		int index=(int)getX(i)+256*(int)getY(i)+1;
		try{
                    map.get(index).add((int)getE(i));
		}
		catch(Exception e){
                    IJ.log("map.g "+e.toString());
		}
            }
	}
	catch (Exception e){
            IJ.log(e.toString());
	}
	for (int i=1;i<map.size();i++){
            java.util.Collections.sort(map.get(i));
            int size=map.get(i).size();
            median.add(map.get(i).get((int)(size/2)));
	}
	return  median;
}
public void saveMedianTextImage(String path){
	try{
		PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(path)));
		
		for (int x=2;x<256;x++) {
			String line="";
			for (int y=1;y<256;y++){
				line+=String.valueOf(median.get(x+256*y))+" ";
			}
			out.println(line);
		}
		out.close();
	}
	catch (Exception e){
	}
}

}